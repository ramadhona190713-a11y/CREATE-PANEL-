/**
 * "Bot Reactch" (controller) — mekanisme LAMA: satu nomor WhatsApp
 * mengetik command `.reactch <link> <emoji,emoji>` ke sebuah grup, lalu
 * (lewat listener pesannya sendiri) mereaksi pesan yang memuat link itu
 * secara berurutan untuk tiap emoji.
 *
 * SEKARANG OPSIONAL, dikontrol lewat config.json -> "botrc":
 *   - botrc = false -> controller ini SAMA SEKALI tidak dijalankan, tidak
 *     perlu pairing apa pun. Reaksi sepenuhnya mengandalkan pool sender
 *     publik (lihat senderPool.js).
 *   - botrc = true  -> controller ini AKTIF, otomatis mencoba konek
 *     (pakai sesi tersimpan) begitu server nyala, dan MENAMBAH SATU
 *     reaksi lagi (dari akun controller ini) di luar reaksi para sender
 *     publik.
 *
 * Login pengguna website SEKARANG lewat Google (lihat googleAuth.js) --
 * controller ini TIDAK LAGI menangani DM ".daftar <token>" apa pun.
 */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");
const QRCode = require("qrcode");
const pino = require("pino");
const path = require("path");
const fs = require("fs");
const { createMessageStore } = require("./messageStore");
const config = require("../config.json");
const systemStatus = require("./systemStatus");

let sock = null;
let isConnected = false;
let lastQrDataUrl = null;
let io = null; // socket.io instance, di-set dari index.js
let started = false;

const messageStore = createMessageStore();
const AUTH_FOLDER = path.join(__dirname, "..", "auth_info");

const REACTCH_REGEX = /^\.reactch\s+(\S+)\s+(.+)$/i;

function isEnabled() {
  return config.botrc === true;
}

function setSocketIo(ioInstance) {
  io = ioInstance;
}

/**
 * Selama web "closed" (/close) atau "maintenance" (/m), controller ini
 * DIHENTIKAN SEMENTARA (tidak memproses .reactch apa pun & tidak bisa
 * dipakai kirim command baru) TAPI koneksi WhatsApp-nya TETAP TERSAMBUNG
 * (bukan logout/disconnect) -- supaya begitu /open atau /sm dipanggil,
 * bot langsung aktif lagi tanpa perlu scan QR ulang.
 */
function isPaused() {
  return systemStatus.isBlocked();
}

function getStatus() {
  return { enabled: isEnabled(), connected: isConnected, paused: isPaused() };
}

function getLastQr() {
  return lastQrDataUrl;
}

/**
 * Dipanggil dari index.js saat server start (kalau botrc=true) ATAU dari
 * endpoint /api/pairing/controller/qr (tombol "Dapatkan QR" di web, kalau
 * belum tersambung). Idempotent -- aman dipanggil berkali-kali.
 */
async function ensureStarted() {
  if (!isEnabled()) return;
  if (started) return;
  started = true;
  await startControllerBot();
}

function extractText(message) {
  if (!message) return "";
  const m =
    message.ephemeralMessage?.message ||
    message.viewOnceMessage?.message ||
    message.viewOnceMessageV2?.message ||
    message;
  return (m?.conversation || m?.extendedTextMessage?.text || "").trim();
}

async function startControllerBot() {
  const { state, saveCreds } = await useMultiFileAuthState(AUTH_FOLDER);
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type && type !== "notify") return;

    for (const msg of messages) {
      const groupId = msg.key?.remoteJid;
      if (!groupId?.endsWith("@g.us")) continue; // controller cuma peduli grup

      messageStore.addMessage(groupId, msg);

      // Pesan tetap disimpan ke messageStore di atas (supaya begitu aktif
      // lagi riwayat pesan tidak kosong), tapi command ".reactch" DIABAIKAN
      // total selama paused -- tidak boleh ada reaksi terkirim sama sekali
      // selagi web closed/maintenance.
      if (isPaused()) continue;

      const text = extractText(msg.message);
      const match = text.match(REACTCH_REGEX);
      if (match) {
        const link = match[1];
        const emojis = match[2]
          .split(",")
          .map((e) => e.trim())
          .filter(Boolean);

        await handleReactchCommand({ groupId, link, emojis, commandMessageKey: msg.key });
      }
    }
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      lastQrDataUrl = await QRCode.toDataURL(qr);
      if (io) io.emit("controller:qr", { qr: lastQrDataUrl });
    }

    if (connection === "open") {
      isConnected = true;
      lastQrDataUrl = null;
      if (io) io.emit("controller:connected", { connected: true });
      console.log("[Rzone][Controller] WhatsApp tersambung.");
      await broadcastPairingSuccess();
    }

    if (connection === "close") {
      isConnected = false;
      if (io) io.emit("controller:connected", { connected: false });
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      console.log("[Rzone][Controller] Koneksi terputus, reconnect:", shouldReconnect);

      if (shouldReconnect) {
        setTimeout(() => {
          startControllerBot().catch((err) => {
            console.error("[Rzone][Controller] Gagal menyambung ulang:", err?.message);
          });
        }, 3000);
      } else {
        started = false;
        try {
          fs.rmSync(AUTH_FOLDER, { recursive: true, force: true });
        } catch (err) {
          console.error("[Rzone][Controller] Gagal hapus sesi lama:", err?.message);
        }
      }
    }
  });

  return sock;
}

async function broadcastPairingSuccess() {
  if (!sock) return;
  try {
    const groups = await sock.groupFetchAllParticipating();
    const groupIds = Object.keys(groups);
    const text =
      "Bot Rzone (controller) berhasil terpasang dan aktif di grup ini. Ketik .reactch <link> <emoji,emoji> untuk auto-react.";
    for (const gid of groupIds) {
      try {
        await sock.sendMessage(gid, { text });
      } catch (err) {
        console.error("[Rzone][Controller] Gagal kirim ke grup", gid, err?.message);
      }
    }
  } catch (err) {
    console.error("[Rzone][Controller] Gagal fetch grup untuk broadcast:", err?.message);
  }
}

/**
 * Diproses SETIAP KALI ada pesan ".reactch <link> <emoji,emoji>" masuk.
 * Bot mereaksi pesan lain di grup yang sama yang memuat `link`, secara
 * berurutan untuk tiap emoji yang diberikan.
 */
async function handleReactchCommand({ groupId, link, emojis, commandMessageKey }) {
  if (!sock || !isConnected) return;

  const targetMessage = messageStore.findMessageByLink(groupId, link, commandMessageKey?.id);
  if (!targetMessage) {
    console.log(`[Rzone][Controller] .reactch: pesan "${link}" belum ditemukan di grup ${groupId}.`);
    return;
  }

  for (const emoji of emojis) {
    try {
      await sock.sendMessage(groupId, { react: { text: emoji, key: targetMessage.key } });
      await new Promise((r) => setTimeout(r, 1500));
    } catch (err) {
      console.error("[Rzone][Controller] Gagal react:", err?.message);
    }
  }
}

/**
 * Dipanggil dari routes/react.js & routes/dev.js kalau botrc=true: tugasnya
 * HANYA mengetik command ".reactch ..." ke grup target, persis seperti
 * anggota grup mengetiknya manual. Eksekusi reaksi ditangani otomatis oleh
 * handleReactchCommand() lewat listener di atas.
 */
async function sendReactchCommand({ link, emojis, targetGroupIds }) {
  if (!isEnabled()) {
    throw new Error("Fitur controller (botrc) sedang dimatikan di config.json.");
  }
  if (isPaused()) {
    const msg = systemStatus.blockedMessage();
    throw new Error(msg || "Bot controller sedang dihentikan sementara.");
  }
  if (!sock || !isConnected) {
    throw new Error("Bot controller belum terpasang (belum pairing).");
  }

  const commandText = `.reactch ${link} ${emojis.join(",")}`;
  const groups = targetGroupIds?.length
    ? targetGroupIds
    : Object.keys(await sock.groupFetchAllParticipating());

  const results = [];
  for (const gid of groups) {
    try {
      await sock.sendMessage(gid, { text: commandText });
      results.push({ groupId: gid, ok: true });
    } catch (err) {
      results.push({ groupId: gid, ok: false, error: err?.message });
    }
  }
  return { commandText, results };
}

module.exports = {
  isEnabled,
  isPaused,
  ensureStarted,
  setSocketIo,
  getStatus,
  getLastQr,
  sendReactchCommand,
};
