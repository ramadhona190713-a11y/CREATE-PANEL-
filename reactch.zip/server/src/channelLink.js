/**
 * Parser link postingan Channel/Saluran WhatsApp.
 *
 * Format link: https://whatsapp.com/channel/<inviteCode>/<messageId>
 *   - <inviteCode>  -> kode undangan channel-nya (huruf+angka)
 *   - <messageId>   -> ID pesan/postingan spesifik (angka, "server_id")
 *
 * React ke Channel BEDA TOTAL dari react ke pesan grup:
 *   - Grup: bot harus jadi ANGGOTA grup itu supaya bisa "melihat" pesannya
 *     lewat messages.upsert, baru bisa mereaksi.
 *   - Channel: react bisa langsung dikirim ke server WhatsApp cukup
 *     bermodalkan JID channel-nya + ID postingannya -- TIDAK PERLU
 *     follow/menjadi anggota channel itu sama sekali.
 *
 * Makanya link yang dibutuhkan HARUS link postingan spesifik (ada angka ID
 * di akhir URL), bukan cuma link channel-nya saja.
 */

function parseChannelLink(link) {
  let url;
  try {
    url = new URL(String(link));
  } catch {
    return null;
  }

  if (!/whatsapp\.com$/i.test(url.hostname.replace(/^www\./i, ""))) {
    return null;
  }

  const parts = url.pathname.split("/").filter(Boolean); // ["channel", "<inviteCode>", "<messageId>?"]
  if (parts[0]?.toLowerCase() !== "channel" || !parts[1]) {
    return null;
  }

  const inviteCode = parts[1];
  const messageId = parts[2] && /^\d+$/.test(parts[2]) ? parts[2] : null;

  return { inviteCode, messageId };
}

module.exports = { parseChannelLink };
