/**
 * Lapisan database — JSON tersinkron ke disk, tanpa dependency native.
 * Versi baru: mendukung sistem KOIN (green/yellow/blue) dan ORDER top up.
 *
 * Semua operasi SYNCHRONOUS = atomik di Node.js single-threaded.
 * File ditulis lewat pola "tulis sementara + rename" (anti korup).
 */

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const DATA_DIR = path.join(__dirname, "data");
fs.mkdirSync(DATA_DIR, { recursive: true });
const DB_FILE = path.join(DATA_DIR, "rzone-db.json");
const TMP_FILE = DB_FILE + ".tmp";

function defaultState() {
  return {
    nextUserId: 1,
    users: [],
    orders: [],       // { reffId, userId, coinType, coinAmount, totalPrice, status, createdAt, paidAt }
    nextLogId: 1,
    usageLog: [],     // { id, user_id, kind, link, at }
    senders: [],      // { id, label, ownerId, createdAt }
    systemStatus: {
      closed: false,
      maintenance: false,
      closedAt: null,
      maintenanceAt: null,
    },
  };
}

function saveState(s) {
  fs.writeFileSync(TMP_FILE, JSON.stringify(s), "utf8");
  fs.renameSync(TMP_FILE, DB_FILE);
}

function loadState() {
  try {
    const parsed = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
    // Migrasi lembut
    if (!Array.isArray(parsed.orders)) parsed.orders = [];
    if (!Array.isArray(parsed.senders)) parsed.senders = [];
    if (!Array.isArray(parsed.usageLog)) parsed.usageLog = [];
    if (!parsed.systemStatus || typeof parsed.systemStatus !== "object") {
      parsed.systemStatus = { closed: false, maintenance: false, closedAt: null, maintenanceAt: null };
    }
    parsed.users = (parsed.users || []).map((u) => ({
      coins: null, // akan diinisialisasi oleh coins.js saat diakses
      ...u,
    }));
    return parsed;
  } catch {
    const fresh = defaultState();
    saveState(fresh);
    return fresh;
  }
}

const state = loadState();

function persist() {
  saveState(state);
}

// ===================== Users =====================

function findUserByEmail(email) {
  return state.users.find((u) => u.email === email) || null;
}
function findUserByApiKey(apiKey) {
  if (!apiKey) return null;
  return state.users.find((u) => u.api_key === apiKey) || null;
}
function findUserById(id) {
  return state.users.find((u) => u.id === id) || null;
}
function createUser(email, googleSub, apiKey) {
  const user = {
    id: state.nextUserId++,
    email,
    google_sub: googleSub,
    api_key: apiKey,
    coins: null, // inisialisasi oleh coins.js
    created_at: new Date().toISOString(),
  };
  state.users.push(user);
  persist();
  return user;
}
function updateUserApiKey(id, newKey) {
  const user = findUserById(id);
  if (!user) return;
  user.api_key = newKey;
  persist();
}
function allUsers() {
  return state.users.slice().sort((a, b) => (a.created_at < b.created_at ? 1 : -1));
}

/**
 * Persist 1 user object (dipanggil coins.js setelah mutasi saldo).
 * Karena user object adalah referensi langsung ke state.users,
 * cukup panggil persist() untuk simpan seluruh state.
 */
function persistUser(_user) {
  persist();
}

// ===================== Orders (top up / payment) =====================

function addOrder(order) {
  state.orders.push(order);
  persist();
}
function findOrder(reffId) {
  return state.orders.find((o) => o.reffId === reffId) || null;
}
function updateOrderStatus(reffId, status) {
  const order = findOrder(reffId);
  if (!order) return;
  order.status = status;
  if (status === "paid") order.paidAt = new Date().toISOString();
  persist();
}
function updateOrderFields(reffId, fields) {
  const order = findOrder(reffId);
  if (!order) return;
  Object.assign(order, fields);
  persist();
}
function getOrdersByUser(userId) {
  return state.orders.filter((o) => o.userId === userId).slice().reverse();
}

// ===================== Log riwayat =====================

function addLog(userId, kind, link) {
  state.usageLog.push({
    id: state.nextLogId++,
    user_id: userId,
    kind,
    link,
    at: new Date().toISOString(),
  });
  persist();
}
function recentLogs(userId, kind, limit) {
  return state.usageLog
    .filter((l) => l.user_id === userId && (kind ? l.kind === kind : true))
    .slice(-limit)
    .reverse();
}
function countLogs(userId) {
  return state.usageLog.filter((l) => l.user_id === userId).length;
}

const DB_WIB_OFFSET_MS = 7 * 60 * 60 * 1000;
function logPeriodKey(isoAt) {
  return new Date(new Date(isoAt).getTime() + DB_WIB_OFFSET_MS).toISOString().slice(0, 10);
}
function countLogsInPeriod(period) {
  return state.usageLog.filter((l) => logPeriodKey(l.at) === period).length;
}
function leaderboardInPeriod(period, limit = 10) {
  const counts = new Map();
  for (const l of state.usageLog) {
    if (logPeriodKey(l.at) !== period) continue;
    counts.set(l.user_id, (counts.get(l.user_id) || 0) + 1);
  }
  return Array.from(counts.entries())
    .map(([userId, count]) => {
      const user = findUserById(userId);
      return { email: user?.email || `user#${userId}`, count };
    })
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

// ===================== Status sistem =====================

function getSystemStatus() {
  return { ...state.systemStatus };
}
function setClosed(value) {
  state.systemStatus.closed = value;
  state.systemStatus.closedAt = value ? new Date().toISOString() : null;
  persist();
}
function setMaintenance(value) {
  state.systemStatus.maintenance = value;
  state.systemStatus.maintenanceAt = value ? new Date().toISOString() : null;
  persist();
}

// ===================== Registry sender WhatsApp publik =====================

function addSenderRecord(id, label, ownerId) {
  if (state.senders.some((s) => s.id === id)) return;
  state.senders.push({
    id,
    label: label || id,
    ownerId: ownerId ?? null,
    createdAt: new Date().toISOString(),
  });
  persist();
}
function removeSenderRecord(id) {
  state.senders = state.senders.filter((s) => s.id !== id);
  persist();
}
function listSenderRecords() {
  return state.senders.slice();
}

function generateRandomToken() {
  return crypto.randomBytes(24).toString("hex");
}

module.exports = {
  findUserByEmail,
  findUserByApiKey,
  findUserById,
  createUser,
  updateUserApiKey,
  allUsers,
  persistUser,
  addOrder,
  findOrder,
  updateOrderStatus,
  updateOrderFields,
  getOrdersByUser,
  addLog,
  recentLogs,
  countLogs,
  countLogsInPeriod,
  leaderboardInPeriod,
  getSystemStatus,
  setClosed,
  setMaintenance,
  addSenderRecord,
  removeSenderRecord,
  listSenderRecords,
  generateRandomToken,
};