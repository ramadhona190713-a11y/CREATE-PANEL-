/**
 * Login pakai Google (OAuth 2.0, "Authorization Code" flow) — SENGAJA
 * ditulis tanpa dependency npm baru (cuma pakai `fetch` bawaan Node 18+),
 * supaya tidak terulang kejadian seperti `better-sqlite3` yang gagal
 * ter-install di hosting Pterodactyl karena butuh kompilasi native.
 *
 * Kenapa Google, bukan WhatsApp lagi: nomor WhatsApp gampang dibuat
 * berkali-kali (SIM baru/nomor virtual) untuk menghindari limit harian.
 * Akun Google jauh lebih "mahal"/tidak praktis dibuat massal, jadi lebih
 * sulit dipakai untuk bypass limit -- walau tetap TIDAK ADA jaminan 100%
 * (lihat catatan jujur di README).
 *
 * Alur:
 *   1. GET /api/auth/google/start -> redirect ke halaman consent Google.
 *   2. Google redirect balik ke /api/auth/google/callback?code=...&state=...
 *   3. Server tukar `code` jadi token (server-to-server, HTTPS langsung ke
 *      Google) -> dapat id_token (JWT) yang berisi email & sub (ID unik
 *      akun Google). Karena didapat LANGSUNG dari endpoint token Google
 *      lewat HTTPS (bukan dari client/browser), id_token ini bisa
 *      dipercaya tanpa perlu verifikasi tanda tangan JWT terpisah.
 */

const crypto = require("crypto");
const config = require("../config.json");

const TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";
const AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";

// State CSRF login Google -- cukup disimpan di memori (bukan file/DB),
// karena umurnya sangat singkat (proses login cuma butuh beberapa detik
// sampai semenit) dan hilang saat restart tidak masalah sama sekali.
const pendingStates = new Map(); // state -> expiresAt (ms)
const STATE_TTL_MS = 10 * 60 * 1000;

function cleanupExpiredStates() {
  const now = Date.now();
  for (const [state, expiresAt] of pendingStates.entries()) {
    if (expiresAt <= now) pendingStates.delete(state);
  }
}

function isConfigured() {
  return Boolean(config.googleClientId && config.googleClientSecret);
}

function getRedirectUri() {
  if (config.googleRedirectUri) return config.googleRedirectUri;
  const base = config.publicBaseUrl || `http://localhost:${config.port || 3000}`;
  return `${base}/api/auth/google/callback`;
}

/**
 * Bangun URL consent screen Google + simpan state CSRF sekali pakai.
 */
function buildAuthUrl() {
  cleanupExpiredStates();
  const state = crypto.randomBytes(16).toString("hex");
  pendingStates.set(state, Date.now() + STATE_TTL_MS);

  const params = new URLSearchParams({
    client_id: config.googleClientId,
    redirect_uri: getRedirectUri(),
    response_type: "code",
    scope: "openid email profile",
    state,
    prompt: "select_account",
  });

  return `${AUTH_ENDPOINT}?${params.toString()}`;
}

function consumeState(state) {
  cleanupExpiredStates();
  if (!state || !pendingStates.has(state)) return false;
  pendingStates.delete(state);
  return true;
}

/**
 * Decode payload JWT TANPA verifikasi tanda tangan -- ini AMAN di sini
 * karena id_token-nya didapat langsung dari respons HTTPS Google sendiri
 * (server-to-server), bukan dari input yang bisa dipalsukan browser/user.
 */
function decodeJwtPayload(jwt) {
  const parts = jwt.split(".");
  if (parts.length !== 3) throw new Error("Format id_token tidak valid.");
  const payload = Buffer.from(parts[1], "base64url").toString("utf8");
  return JSON.parse(payload);
}

/**
 * Tukar authorization code jadi profil user (email, sub, name).
 * Melempar error kalau code tidak valid/kedaluwarsa/config Google salah.
 */
async function exchangeCodeForProfile(code) {
  const res = await fetch(TOKEN_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      code,
      client_id: config.googleClientId,
      client_secret: config.googleClientSecret,
      redirect_uri: getRedirectUri(),
      grant_type: "authorization_code",
    }),
  });

  const data = await res.json();
  if (!res.ok || !data.id_token) {
    throw new Error(data.error_description || data.error || "Gagal login dengan Google.");
  }

  const payload = decodeJwtPayload(data.id_token);
  if (!payload.email) {
    throw new Error("Akun Google tidak memiliki email yang bisa diverifikasi.");
  }
  if (payload.email_verified === false) {
    throw new Error("Email akun Google ini belum diverifikasi oleh Google.");
  }

  return {
    email: payload.email,
    sub: payload.sub,
    name: payload.name || null,
  };
}

module.exports = { isConfigured, buildAuthUrl, consumeState, exchangeCodeForProfile };
