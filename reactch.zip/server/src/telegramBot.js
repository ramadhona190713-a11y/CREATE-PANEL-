/**
 * Bot Telegram ADMIN — versi baru dengan sistem KOIN.
 *
 * Command:
 *   /accounts        — daftar semua akun + saldo koin
 *   /account <email> — detail 1 akun
 *   /addcoins <email> <green|yellow|blue> <jumlah> — tambah koin manual
 *   /senders         — daftar sender WhatsApp
 *   /close /open     — tutup/buka web
 *   /m /sm           — maintenance
 *   /statuswebsite   — cek status
 *   /reacthariini    — jumlah react hari ini
 *   /leaderboard     — ranking hari ini
 *   /help            — bantuan
 *
 * KEAMANAN: hanya merespons chat ID di config.telegramBot.adminChatIds.
 */

const accounts = require("./accounts");
const senderPool = require("./senderPool");
const controllerBot = require("./controllerBot");
const systemStatus = require("./systemStatus");
const coins = require("./coins");
const db = require("./db");

const API_BASE = "https://api.telegram.org/bot";
const POLL_TIMEOUT_SEC = 30;

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function chunkMessage(lines, sep = "\n\n", maxLen = 3500) {
  const chunks = [];
  let current = "";
  for (const line of lines) {
    const candidate = current ? current + sep + line : line;
    if (candidate.length > maxLen && current) {
      chunks.push(current);
      current = line;
    } else {
      current = candidate;
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

function createTelegramBot(config) {
  const cfg = config?.telegramBot;
  if (!cfg || !cfg.enabled) {
    console.log("[TelegramBot] Nonaktif (telegramBot.enabled=false di config.json).");
    return { start() {}, stop() {} };
  }
  if (!cfg.botToken || typeof cfg.botToken !== "string" || cfg.botToken.length < 20) {
    console.log("[TelegramBot] Nonaktif: telegramBot.botToken belum diisi.");
    return { start() {}, stop() {} };
  }
  const adminChatIds = new Set((cfg.adminChatIds || []).map((id) => String(id)));
  if (adminChatIds.size === 0) {
    console.log("[TelegramBot] Nonaktif: telegramBot.adminChatIds masih kosong.");
    return { start() {}, stop() {} };
  }

  const apiUrl = `${API_BASE}${cfg.botToken}`;
  let running = false;
  let offset = 0;

  async function callApi(method, body) {
    const res = await fetch(`${apiUrl}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return res.json();
  }

  async function sendMessage(chatId, text) {
    try {
      await callApi("sendMessage", {
        chat_id: chatId,
        text,
        parse_mode: "HTML",
        disable_web_page_preview: true,
      });
    } catch (err) {
      console.error("[TelegramBot] Gagal kirim pesan:", err.message);
    }
  }

  const HELP_TEXT =
    "<b>Rzone WA Bot — Admin Panel (Sistem Koin)</b>\n\n" +
    "/accounts — daftar semua akun & saldo koin\n" +
    "/account &lt;email&gt; — detail 1 akun\n" +
    "/addcoins &lt;email&gt; &lt;green|yellow|blue&gt; &lt;jumlah&gt; — tambah koin manual\n" +
    "/senders — daftar sender WhatsApp aktif\n\n" +
    "<b>Tutup / Maintenance</b>\n" +
    "/close — tutup web+API\n" +
    "/open — buka lagi\n" +
    "/m — mode maintenance\n" +
    "/sm — selesai maintenance\n" +
    "/statuswebsite — cek status\n\n" +
    "<b>Statistik</b>\n" +
    "/reacthariini — jumlah react hari ini\n" +
    "/leaderboard — ranking react hari ini\n\n" +
    "/help — tampilkan pesan ini";

  async function handleCommand(chatId, text) {
    const parts = text.trim().split(/\s+/);
    const cmd = (parts[0] || "").toLowerCase().replace(/@.*$/, "");

    if (cmd === "/start" || cmd === "/help") {
      return sendMessage(chatId, HELP_TEXT);
    }

    if (cmd === "/accounts") {
      const accountList = accounts.listAccountsSummary();
      if (accountList.length === 0) {
        return sendMessage(chatId, "Belum ada akun terdaftar.");
      }
      const lines = accountList.map(
        (acc) =>
          `• <b>${escapeHtml(acc.email)}</b>\n` +
          `  key: <code>${escapeHtml(acc.apiKeyMasked)}</code>\n` +
          `  Hijau ${acc.greenCoins} | Kuning ${acc.yellowCoins} | Biru ${acc.blueCoins} | total react: ${acc.totalRequests}`
      );
      const chunks = chunkMessage(lines);
      for (const chunk of chunks) await sendMessage(chatId, chunk);
      return;
    }

    if (cmd === "/account") {
      const email = parts[1];
      if (!email) return sendMessage(chatId, "Format: /account nama@gmail.com");
      const detail = accounts.findAccountDetail(email);
      if (!detail) return sendMessage(chatId, "Akun tidak ditemukan.");
      const c = detail.coins;
      const linksText =
        detail.recentLinks.length > 0
          ? detail.recentLinks
              .map((l) => `  - ${escapeHtml(l.link)} (${new Date(l.at).toLocaleString("id-ID")})`)
              .join("\n")
          : "  (belum ada)";
      return sendMessage(
        chatId,
        `<b>${escapeHtml(detail.email)}</b>\n` +
          `key: <code>${escapeHtml(detail.apiKeyMasked)}</code>\n` +
          `Hijau: ${c.green.balance} (restock ${c.green.dailyRestock}/hari)\n` +
          `Kuning: ${c.yellow.balance}\n` +
          `Biru: ${c.blue.balance} (restock ${c.blue.dailyRestock}/hari)\n` +
          `total react: ${detail.totalRequests}\n\n` +
          `5 aktivitas terakhir:\n${linksText}`
      );
    }

    if (cmd === "/addcoins") {
      const email = parts[1];
      const coinType = parts[2];
      const amount = Number(parts[3]);
      if (!email || !coinType || !parts[3]) {
        return sendMessage(chatId, "Format: /addcoins nama@gmail.com green 10");
      }
      if (!["green", "yellow", "blue"].includes(coinType)) {
        return sendMessage(chatId, "Jenis koin: green, yellow, atau blue.");
      }
      if (!Number.isInteger(amount) || amount <= 0) {
        return sendMessage(chatId, "Jumlah harus angka bulat positif.");
      }
      const user = db.findUserByEmail(email);
      if (!user) return sendMessage(chatId, "Akun tidak ditemukan.");
      try {
        const newBalance = coins.addCoins(user.id, coinType, amount);
        return sendMessage(
          chatId,
          `[OK] +${amount} koin ${coins.COIN_TYPES[coinType].label} untuk <b>${escapeHtml(email)}</b>.\nSaldo sekarang: ${newBalance}`
        );
      } catch (err) {
        return sendMessage(chatId, `[Gagal] ${escapeHtml(err.message)}`);
      }
    }

    if (cmd === "/senders") {
      const list = senderPool.listSenders();
      const active = list.filter((s) => s.status === "connected");
      if (list.length === 0) {
        return sendMessage(chatId, "Belum ada sender publik.");
      }
      const lines = list.map(
        (s) =>
          `• ${escapeHtml(s.phoneNumber || s.id)} — ${s.status === "connected" ? "aktif" : escapeHtml(s.status)}`
      );
      return sendMessage(chatId, `<b>Sender aktif: ${active.length}/${list.length}</b>\n\n${lines.join("\n")}`);
    }

    if (cmd === "/close") {
      systemStatus.setClosed(true);
      return sendMessage(chatId, "Web DITUTUP. Semua fitur nonaktif sampai /open.");
    }

    if (cmd === "/open") {
      systemStatus.setClosed(false);
      return sendMessage(chatId, "Web DIBUKA lagi.");
    }

    if (cmd === "/m") {
      systemStatus.setMaintenance(true);
      return sendMessage(chatId, "Mode MAINTENANCE aktif.");
    }

    if (cmd === "/sm") {
      systemStatus.setMaintenance(false);
      return sendMessage(chatId, "Maintenance SELESAI.");
    }

    if (cmd === "/statuswebsite") {
      const s = systemStatus.getStatus();
      const lines = [
        `Closed: ${s.closed ? "YA" : "TIDAK"}`,
        `Maintenance: ${s.maintenance ? "YA" : "TIDAK"}`,
        `Controller: ${controllerBot.isPaused() ? "pause" : "normal"}`,
      ];
      return sendMessage(chatId, `<b>Status Website</b>\n\n${lines.join("\n")}`);
    }

    if (cmd === "/reacthariini") {
      const total = accounts.getTodayReactCount();
      return sendMessage(chatId, `Jumlah react hari ini: <b>${total}</b>`);
    }

    if (cmd === "/leaderboard") {
      const rows = accounts.getTodayLeaderboard(10);
      if (rows.length === 0) return sendMessage(chatId, "Belum ada react hari ini.");
      const lines = rows.map((r, i) => `${i + 1}. ${escapeHtml(r.email)} — ${r.count}x`);
      return sendMessage(chatId, `<b>Leaderboard React Hari Ini</b>\n\n${lines.join("\n")}`);
    }

    return sendMessage(chatId, "Perintah tidak dikenal. Ketik /help.");
  }

  async function pollLoop() {
    while (running) {
      try {
        const data = await callApi("getUpdates", {
          timeout: POLL_TIMEOUT_SEC,
          offset,
          allowed_updates: ["message"],
        });
        if (data.ok && Array.isArray(data.result)) {
          for (const update of data.result) {
            offset = update.update_id + 1;
            const msg = update.message;
            if (!msg || !msg.text || !msg.chat) continue;
            const chatId = String(msg.chat.id);
            if (!adminChatIds.has(chatId)) continue;
            if (!msg.text.startsWith("/")) continue;
            await handleCommand(chatId, msg.text);
          }
        }
      } catch (err) {
        console.error("[TelegramBot] Polling error:", err.message);
        await new Promise((r) => setTimeout(r, 5000));
      }
    }
  }

  return {
    start() {
      if (running) return;
      running = true;
      console.log("[TelegramBot] Aktif, mendengarkan perintah admin...");
      callApi("getUpdates", { timeout: 0 })
        .then((data) => {
          if (data.ok && Array.isArray(data.result) && data.result.length > 0) {
            offset = data.result[data.result.length - 1].update_id + 1;
          }
        })
        .catch(() => {})
        .finally(() => pollLoop());
    },
    stop() {
      running = false;
    },
  };
}

module.exports = { createTelegramBot };