const express = require("express");
const router = express.Router();
const accounts = require("../accounts");
const session = require("../session");
const senderPool = require("../senderPool");
const controllerBot = require("../controllerBot");
const reactEngine = require("../reactEngine");
const systemStatus = require("../systemStatus");
const coins = require("../coins");

// Blokir kalau closed/maintenance
router.use((req, res, next) => {
  if (systemStatus.isBlocked()) {
    return res.status(503).json({
      error: systemStatus.blockedMessage(),
      closed: systemStatus.isClosed(),
      maintenance: systemStatus.isMaintenance(),
    });
  }
  next();
});

// WAJIB LOGIN
router.use(session.requireAuth);

// GET /api/react/status — info koin + sender aktif
router.get("/status", (req, res) => {
  const coinInfo = coins.getCoinInfo(req.user);
  res.json({
    ok: true,
    coins: coinInfo,
    activeSenderCount: senderPool.getActiveCount(),
  });
});

// POST /api/react
// body: { link, emojis, coinType: "green"|"yellow" }
// Di WEB hanya bisa pilih koin HIJAU atau KUNING.
router.post("/", async (req, res) => {
  try {
    const { link, emojis, coinType } = req.body || {};

    const inputError = reactEngine.validateReactInput(link, emojis);
    if (inputError) {
      return res.status(400).json({ error: inputError });
    }

    // Validasi: web HANYA bisa pakai green atau yellow
    const selectedCoin = coinType || "green";
    if (!["green", "yellow"].includes(selectedCoin)) {
      return res.status(400).json({ error: "React via web hanya bisa pakai koin Hijau atau Kuning." });
    }

    // Cek saldo koin
    if (!coins.canAfford(req.user, selectedCoin, 1)) {
      const coinLabel = coins.COIN_TYPES[selectedCoin].label;
      return res.status(402).json({
        error: `Koin ${coinLabel} kamu habis. Top up dulu untuk melanjutkan.`,
        needTopUp: true,
        coinType: selectedCoin,
      });
    }

    // Cek sender aktif
    if (senderPool.getActiveCount() === 0 && !controllerBot.isEnabled()) {
      return res.status(503).json({
        error: "Tidak ada sender WhatsApp yang aktif saat ini. Coba lagi nanti.",
      });
    }

    // Konsumsi koin (atomik)
    const consumed = coins.consumeCoin(req.user, selectedCoin, 1);
    if (!consumed) {
      return res.status(402).json({ error: "Koin tidak cukup.", needTopUp: true });
    }

    // Eksekusi react. Koin sudah terpotong di atas -- kalau eksekusi
    // error ATAU tidak ada satu pun reaksi yang terkirim, koin dikembalikan.
    let result;
    try {
      result = await reactEngine.executeReact({ link, emojis });
    } catch (err) {
      coins.refundCoin(req.user, selectedCoin, 1);
      throw err;
    }

    const success = reactEngine.didSucceed(result);
    let refunded = false;
    if (success) {
      accounts.recordLog(req.user.id, "web", link);
    } else {
      coins.refundCoin(req.user, selectedCoin, 1);
      refunded = true;
    }

    res.json({
      ok: true,
      success,
      refunded,
      coinUsed: selectedCoin,
      coins: coins.getCoinInfo(req.user),
      result,
    });
  } catch (err) {
    if (err.code === "NO_ACTIVE_SENDER" || err.code === "SYSTEM_BLOCKED") {
      return res.status(503).json({ error: err.message, coins: coins.getCoinInfo(req.user) });
    }
    console.error("[React] Error:", err);
    res.status(500).json({ error: "Gagal memproses permintaan.", coins: coins.getCoinInfo(req.user) });
  }
});

module.exports = router;