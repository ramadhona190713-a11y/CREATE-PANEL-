const express = require("express");
const router = express.Router();
const accounts = require("../accounts");
const session = require("../session");
const senderPool = require("../senderPool");
const reactEngine = require("../reactEngine");
const systemStatus = require("../systemStatus");
const coins = require("../coins");

// Blokir kalau closed/maintenance
router.use((req, res, next) => {
  if (systemStatus.isBlocked()) {
    return res.status(503).json({
      error: systemStatus.blockedMessage(),
      closed: systemStatus.isClosed(),
      maintenance: systemStatus.isMaintenance(),
    });
  }
  next();
});

// Middleware API key + konsumsi koin BIRU
function requireApiKey(req, res, next) {
  const apiKey = req.header("x-api-key");
  if (!apiKey) return res.status(401).json({ error: "Header x-api-key wajib diisi." });

  const user = accounts.findByApiKey(apiKey);
  if (!user) return res.status(401).json({ error: "API key tidak valid." });

  // API SELALU pakai koin Biru
  if (!coins.canAfford(user, "blue", 1)) {
    return res.status(402).json({
      error: "Koin Biru habis. Top up dulu untuk melanjutkan.",
      needTopUp: true,
      coinType: "blue",
    });
  }

  const consumed = coins.consumeCoin(user, "blue", 1);
  if (!consumed) {
    return res.status(402).json({ error: "Koin Biru tidak cukup.", needTopUp: true });
  }

  req.apiUser = user;
  const coinInfo = coins.getCoinInfo(user);
  res.setHeader("X-Blue-Coins-Remaining", coinInfo.blue.balance);
  next();
}

function refreshBlueHeader(req, res) {
  res.setHeader("X-Blue-Coins-Remaining", coins.getCoinInfo(req.apiUser).blue.balance);
}

// POST /api/dev/react
router.post("/react", requireApiKey, async (req, res) => {
  try {
    const { link, emojis, targetGroupIds } = req.body || {};
    const inputError = reactEngine.validateReactInput(link, emojis);
    if (inputError) {
      // Koin biru dipotong di middleware -- kembalikan karena request tidak valid.
      coins.refundCoin(req.apiUser, "blue", 1);
      refreshBlueHeader(req, res);
      return res.status(400).json({ error: inputError });
    }

    let result;
    try {
      result = await reactEngine.executeReact({ link, emojis, targetGroupIds });
    } catch (err) {
      coins.refundCoin(req.apiUser, "blue", 1);
      refreshBlueHeader(req, res);
      throw err;
    }

    const success = reactEngine.didSucceed(result);
    if (success) {
      accounts.recordLog(req.apiUser.id, "api", link);
    } else {
      coins.refundCoin(req.apiUser, "blue", 1);
      refreshBlueHeader(req, res);
    }
    res.json({ ok: true, success, refunded: !success, result });
  } catch (err) {
    if (err.code === "NO_ACTIVE_SENDER" || err.code === "SYSTEM_BLOCKED") {
      return res.status(503).json({ error: err.message });
    }
    console.error("[DevReact] Error:", err);
    res.status(500).json({ error: "Gagal memproses permintaan." });
  }
});

// GET /api/dev/me — lihat API key + info koin
router.get("/me", session.requireAuth, (req, res) => {
  const coinInfo = coins.getCoinInfo(req.user);
  res.json({ ok: true, email: req.user.email, apiKey: req.user.api_key, coins: coinInfo });
});

// POST /api/dev/regenerate
router.post("/regenerate", session.requireAuth, (req, res) => {
  const newKey = accounts.regenerateApiKey(req.user.id);
  res.json({ ok: true, apiKey: newKey });
});

// GET /api/dev/stats
router.get("/stats", session.requireAuth, (req, res) => {
  const coinInfo = coins.getCoinInfo(req.user);
  const db = require("../db");
  const history = db.recentLogs(req.user.id, "api", 50);
  const totalRequests = db.countLogs(req.user.id);

  res.json({
    ok: true,
    email: req.user.email,
    coins: coinInfo,
    stats: { totalRequests },
    history,
  });
});

module.exports = router;