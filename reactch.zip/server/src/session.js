/**
 * Sesi login — SEKARANG WAJIB untuk semua fitur (react web maupun API
 * developer), TIDAK ADA LAGI mode anonim/tanpa login. Login sekarang
 * lewat Google (lihat googleAuth.js) -- login berbasis nomor WhatsApp
 * sudah dihapus total (gampang dibuat berkali-kali untuk bypass limit).
 *
 * Sesi disimpan sebagai JWT di cookie httpOnly (jadi tidak bisa
 * dibaca/diubah lewat JavaScript di browser), ditandatangani pakai secret
 * yang SUDAH ADA di config.json (`developerMode.jwtSecret`) -- tidak perlu
 * key config baru untuk ini.
 */

const jwt = require("jsonwebtoken");
const config = require("../config.json");
const accounts = require("./accounts");

const COOKIE_NAME = "rzone_sess";
const SESSION_TTL_SEC = 60 * 60 * 24 * 30; // 30 hari

function getSecret() {
  const secret = config?.developerMode?.jwtSecret;
  if (!secret || typeof secret !== "string" || secret.length < 8) {
    return "rzone-fallback-secret-ganti-ini-di-config-json";
  }
  return secret;
}

function parseCookies(req) {
  const header = req.headers.cookie;
  const out = {};
  if (!header) return out;
  header.split(";").forEach((pair) => {
    const idx = pair.indexOf("=");
    if (idx === -1) return;
    const k = pair.slice(0, idx).trim();
    const v = pair.slice(idx + 1).trim();
    if (k) out[k] = decodeURIComponent(v);
  });
  return out;
}

function issueSession(res, userId, secure = false) {
  const token = jwt.sign({ uid: userId }, getSecret(), { expiresIn: SESSION_TTL_SEC });
  res.append(
    "Set-Cookie",
    `${COOKIE_NAME}=${encodeURIComponent(token)}; Max-Age=${SESSION_TTL_SEC}; Path=/; HttpOnly; SameSite=Lax${secure ? "; Secure" : ""}`
  );
}

function clearSession(res) {
  res.append("Set-Cookie", `${COOKIE_NAME}=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax`);
}

function getSessionUser(req) {
  const cookies = parseCookies(req);
  const raw = cookies[COOKIE_NAME];
  if (!raw) return null;
  try {
    const payload = jwt.verify(raw, getSecret());
    return accounts.findById(payload.uid) || null;
  } catch {
    return null;
  }
}

/**
 * Middleware WAJIB login. Kalau cookie sesi tidak ada / tidak valid /
 * akunnya sudah tidak ada di DB, request ditolak 401 DI SINI JUGA --
 * sebelum masuk ke logika fitur (react/dev) sama sekali. Tidak ada jalur
 * mana pun lagi yang membiarkan request anonim lewat.
 */
function requireAuth(req, res, next) {
  const user = getSessionUser(req);
  if (!user) {
    return res.status(401).json({ error: "Belum login. Silakan login dengan Google terlebih dahulu." });
  }
  req.user = user;
  next();
}

module.exports = { issueSession, clearSession, requireAuth, getSessionUser, COOKIE_NAME };
