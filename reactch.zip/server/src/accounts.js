/**
 * Manajemen akun — identitas = EMAIL GOOGLE.
 * Versi baru: TIDAK ADA lagi sistem limit harian / bonus sender / redeem.
 * Semua "kuota" sekarang berbasis KOIN (lihat coins.js).
 *
 * File ini tetap ada untuk:
 *   - findOrCreateByEmail (dipakai auth callback)
 *   - findByApiKey (dipakai middleware API)
 *   - findById
 *   - regenerateApiKey
 *   - maskApiKey
 *   - listAccountsSummary (untuk Telegram admin bot)
 *   - getTodayReactCount / getTodayLeaderboard (untuk Telegram admin bot)
 */

const crypto = require("crypto");
const db = require("./db");
const coins = require("./coins");

function generateApiKey() {
  return "rzone_" + crypto.randomBytes(24).toString("hex");
}

function maskApiKey(apiKey) {
  if (!apiKey || apiKey.length < 14) return "****";
  return `${apiKey.slice(0, 10)}...${apiKey.slice(-4)}`;
}

function findOrCreateByEmail(email, googleSub) {
  const existing = db.findUserByEmail(email);
  if (existing) return existing;
  return db.createUser(email, googleSub, generateApiKey());
}

function findByApiKey(apiKey) {
  return db.findUserByApiKey(apiKey);
}

function findById(id) {
  return db.findUserById(id);
}

function recordLog(userId, kind, link) {
  db.addLog(userId, kind, link);
}

function regenerateApiKey(userId) {
  const newKey = generateApiKey();
  db.updateUserApiKey(userId, newKey);
  return newKey;
}

/** Total react hari ini WIB (semua user & kind). */
function getTodayReactCount() {
  return db.countLogsInPeriod(coins.periodKey());
}

/** Ranking user paling banyak react hari ini WIB. */
function getTodayLeaderboard(limit = 10) {
  return db.leaderboardInPeriod(coins.periodKey(), limit);
}

// ===================== ADMIN (Telegram bot) =====================

function listAccountsSummary() {
  return db.allUsers().map((u) => {
    const coinInfo = coins.getCoinInfo(u);
    return {
      email: u.email,
      apiKeyMasked: maskApiKey(u.api_key),
      greenCoins: coinInfo.green.balance,
      yellowCoins: coinInfo.yellow.balance,
      blueCoins: coinInfo.blue.balance,
      totalRequests: db.countLogs(u.id),
    };
  });
}

function findAccountDetail(email) {
  const u = db.findUserByEmail(email);
  if (!u) return null;
  const coinInfo = coins.getCoinInfo(u);
  return {
    email: u.email,
    apiKeyMasked: maskApiKey(u.api_key),
    coins: coinInfo,
    totalRequests: db.countLogs(u.id),
    recentLinks: db.recentLogs(u.id, null, 5),
  };
}

module.exports = {
  findOrCreateByEmail,
  findByApiKey,
  findById,
  recordLog,
  regenerateApiKey,
  getTodayReactCount,
  getTodayLeaderboard,
  maskApiKey,
  listAccountsSummary,
  findAccountDetail,
};