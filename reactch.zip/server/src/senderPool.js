/**
 * Pool "sender publik" — SIAPA PUN bisa menghubungkan nomor WhatsApp-nya
 * sendiri lewat halaman /pairing (menu "Tambah Sender"), TIDAK TERBATAS
 * jumlahnya.
 *
 * Saat ada request react masuk dengan beberapa emoji sekaligus, SETIAP
 * sender yang sedang aktif (terhubung) memilih SATU emoji SECARA ACAK dari
 * daftar itu, lalu mereaksi POSTINGAN CHANNEL target-nya sendiri-sendiri --
 * jadi kalau ada 5 sender aktif, postingan akan dapat 5 reaksi (masing-
 * masing acak dari daftar emoji), meniru banyak akun asli yang bereaksi
 * secara natural.
 *
 * PENTING soal Channel/Saluran WhatsApp (BEDA DARI GRUP):
 *   - React ke postingan Channel TIDAK PERLU follow/menjadi anggota
 *     channel itu -- cukup bermodalkan JID channel-nya + ID postingannya,
 *     dikirim langsung lewat API `newsletterReactMessage` bawaan Baileys.
 *   - Makanya di sini TIDAK ADA lagi "cari pesan di riwayat grup" seperti
 *     mekanisme lama -- link yang dikirim user harus link POSTINGAN
 *     spesifik (ada ID angka di akhir URL), lihat channelLink.js.
 *
 * PENTING soal metode "Pairing" (bukan QR): kode pairing di sini SELALU
 * benar-benar diminta ke server WhatsApp lewat `sock.requestPairingCode()`
 * bawaan Baileys -- BUKAN kode acak buatan sendiri. Kalau nomor yang
 * dimasukkan salah/tidak valid, WhatsApp sendiri yang akan menolaknya,
 * dan error itu diteruskan apa adanya ke pengguna.
 */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} = require("@whiskeysockets/baileys");
const QRCode = require("qrcode");
const pino = require("pino");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const db = require("./db");
const accounts = require("./accounts");
const { parseChannelLink } = require("./channelLink");

// Channel yang WAJIB otomatis di-follow setiap kali 1 sender berhasil
// konek (follow ulang channel yang sudah di-follow aman, tidak error).
const PROMO_CHANNEL_LINK = "https://whatsapp.com/channel/0029Vb8TfRj5Ui2Pby1ezb0O";
const PROMO_CHANNEL_INVITE_CODE = parseChannelLink(PROMO_CHANNEL_LINK)?.inviteCode || null;

const SENDERS_AUTH_DIR = path.join(__dirname, "..", "auth_info_senders");
fs.mkdirSync(SENDERS_AUTH_DIR, { recursive: true });

const senders = new Map(); // id -> record (lihat startSenderSocket)
let io = null;

function setSocketIo(ioInstance) {
  io = ioInstance;
}

/**
 * Samarkan nomor: cuma 2 digit awal + 3 digit akhir yang ditampilkan.
 * Nomor ASLI tidak pernah dikirim ke client (baik lewat REST maupun
 * broadcast socket.io) -- masking dilakukan di sini, di sumbernya.
 */
function maskPhoneNumber(phone) {
  if (!phone) return null;
  const digits = String(phone).replace(/[^0-9]/g, "");
  if (digits.length <= 5) return digits; // terlalu pendek untuk dipotong aman
  return digits.slice(0, 2) + "*".repeat(digits.length - 5) + digits.slice(-3);
}

function sanitize(record) {
  return {
    id: record.id,
    label: record.label,
    status: record.status,
    phoneNumber: maskPhoneNumber(record.phoneNumber),
    connectedAt: record.connectedAt,
    qr: record.qrDataUrl,
    pairingCode: record.pairingCode,
    error: record.error || null,
  };
}

function emitUpdate(record) {
  if (io) io.emit("sender:update", sanitize(record));
}

function emitRemoved(id) {
  if (io) io.emit("sender:removed", { id });
}

function listSenders(viewerUserId = null) {
  // `ownerId` mentah SENGAJA tidak pernah dikirim ke client (baik lewat
  // sini maupun broadcast socket.io) -- yang dikirim cuma `isMine`,
  // dihitung relatif terhadap viewer yang sedang meminta.
  return Array.from(senders.values()).map((r) => ({
    ...sanitize(r),
    isMine: viewerUserId != null && r.ownerId === viewerUserId,
  }));
}

function getActiveCount() {
  return Array.from(senders.values()).filter((r) => r.status === "connected").length;
}

function getActiveSenders() {
  return Array.from(senders.values()).filter((r) => r.status === "connected");
}

/**
 * Mulai (atau sambung ulang) 1 sesi sender. `opts.method` cuma dipakai
 * saat PERTAMA KALI dipasang ('qr' atau 'pairing') -- untuk reconnect
 * sesi yang sudah pernah tersambung, tidak perlu opts apa pun sama sekali
 * (Baileys otomatis pakai kredensial tersimpan, tanpa QR/pairing ulang).
 */
async function startSenderSocket(id, opts = {}) {
  const authFolder = path.join(SENDERS_AUTH_DIR, id);
  const { state, saveCreds } = await useMultiFileAuthState(authFolder);
  const { version } = await fetchLatestBaileysVersion();

  const record = senders.get(id) || {
    id,
    label: String(opts.label || id).slice(0, 40),
    ownerId: opts.ownerId ?? null,
    status: "connecting",
    qrDataUrl: null,
    pairingCode: null,
    phoneNumber: opts.phoneNumber || null,
    connectedAt: null,
    error: null,
    // Cache JID channel per kode undangan, supaya tidak perlu panggil
    // newsletterMetadata() berulang-ulang untuk link channel yang sama.
    channelJidCache: new Map(),
  };
  // Kalau record SUDAH ada (mis. lagi reconnect) tapi opts.ownerId dikirim
  // (dari registry saat startup), pastikan tetap tersinkron.
  if (opts.ownerId !== undefined && record.ownerId == null) {
    record.ownerId = opts.ownerId;
  }
  record.status = "connecting";
  record.error = null;
  senders.set(id, record);
  emitUpdate(record);

  const usePairing = opts.method === "pairing" && !state.creds.registered;

  const sock = makeWASocket({
    version,
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
  });
  record.sock = sock;

  sock.ev.on("creds.update", saveCreds);

  // === Minta kode pairing ASLI dari WhatsApp (bukan kode buatan sendiri) ===
  if (usePairing) {
    try {
      const cleanNumber = String(opts.phoneNumber).replace(/[^0-9]/g, "");
      if (!cleanNumber || cleanNumber.length < 8) {
        throw new Error("Nomor WhatsApp tidak valid. Pakai format internasional, contoh: 62812xxxxxxx.");
      }
      const code = await sock.requestPairingCode(cleanNumber);
      record.pairingCode = code;
      record.status = "waiting_pairing_code";
      record.phoneNumber = cleanNumber;
      emitUpdate(record);
    } catch (err) {
      record.status = "error";
      record.error = err?.message || "Gagal meminta kode pairing dari WhatsApp.";
      emitUpdate(record);
      try { sock.end(undefined); } catch {}
      return record;
    }
  }

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr && opts.method !== "pairing") {
      try {
        record.qrDataUrl = await QRCode.toDataURL(qr);
        record.status = "qr";
        emitUpdate(record);
      } catch (err) {
        console.error(`[Rzone][Sender:${id}] Gagal membuat QR:`, err?.message);
      }
    }

    if (connection === "open") {
      record.status = "connected";
      record.qrDataUrl = null;
      record.pairingCode = null;
      record.error = null;
      record.connectedAt = new Date().toISOString();
      record.phoneNumber = sock.user?.id?.split(":")?.[0]?.split("@")?.[0] || record.phoneNumber;
      db.addSenderRecord(id, record.label, record.ownerId);
      emitUpdate(record);
      console.log(`[Rzone][Sender:${id}] Tersambung sebagai ${record.phoneNumber || "?"}`);

      // (Sistem bonus sender dihapus — sekarang berbasis koin, lihat coins.js)

      // Auto-follow channel promosi -- fire-and-forget, tidak menghalangi
      // apa pun kalau gagal (mis. channel sudah tidak ada).
      if (PROMO_CHANNEL_INVITE_CODE && typeof sock.newsletterFollow === "function") {
        resolveChannelJid(record, PROMO_CHANNEL_INVITE_CODE)
          .then((jid) => sock.newsletterFollow(jid))
          .then(() => console.log(`[Rzone][Sender:${id}] Follow channel promosi berhasil.`))
          .catch((err) =>
            console.error(`[Rzone][Sender:${id}] Gagal follow channel promosi:`, err?.message)
          );
      }
    }

    if (connection === "close") {
      const wasConnected = record.status === "connected";
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;

      // (Penalti sender dihapus — sekarang berbasis koin, lihat coins.js)

      if (shouldReconnect) {
        record.status = "disconnected";
        emitUpdate(record);
        console.log(`[Rzone][Sender:${id}] Terputus, mencoba menyambung ulang...`);
        setTimeout(() => {
          if (!senders.has(id)) return; // sudah dihapus manual
          startSenderSocket(id, {}).catch((err) =>
            console.error(`[Rzone][Sender:${id}] Gagal menyambung ulang:`, err?.message)
          );
        }, 3000);
      } else {
        console.log(`[Rzone][Sender:${id}] Logout, sesi dihapus.`);
        senders.delete(id);
        db.removeSenderRecord(id);
        try {
          fs.rmSync(authFolder, { recursive: true, force: true });
        } catch (err) {
          console.error(`[Rzone][Sender:${id}] Gagal hapus folder sesi:`, err?.message);
        }
        emitRemoved(id);
      }
    }
  });

  return record;
}

/**
 * Dipanggil dari POST /api/pairing/senders. `label` opsional (nama
 * tampilan saja), `method` = 'qr' | 'pairing', `phoneNumber` wajib kalau
 * method = 'pairing'. `ownerId` WAJIB (id akun Google yang sedang login --
 * dicek di routes/pairing.js sebelum sampai sini) supaya sender ini nanti
 * hanya bisa dihapus oleh pemiliknya sendiri.
 */
async function createSender({ method, phoneNumber, label, ownerId }) {
  const id = crypto.randomUUID();
  const record = await startSenderSocket(id, { method, phoneNumber, label, ownerId });
  return sanitize(record);
}

/**
 * Hapus 1 sender (logout WhatsApp-nya + bersihkan sesi tersimpan).
 * `requestingUserId` WAJIB cocok dengan pemilik sender -- kalau tidak,
 * mengembalikan string "forbidden" (BUKAN throw) supaya route bisa
 * membalas 403 dengan pesan yang jelas. Sender yang tidak bertuan
 * (ownerId null, dari data lama sebelum fitur ini ada) tidak bisa dihapus
 * lewat web sama sekali -- harus dihapus manual di server.
 */
async function removeSender(id, requestingUserId) {
  const record = senders.get(id);
  if (!record) return "not_found";
  if (record.ownerId == null || record.ownerId !== requestingUserId) {
    return "forbidden";
  }
  try {
    await record.sock?.logout();
  } catch {
    // Kalau logout gagal (mis. sudah putus duluan), tetap lanjut bersihkan
    // lokal supaya tidak ada sender "hantu" yang nyangkut di daftar.
  }
  senders.delete(id);
  db.removeSenderRecord(id);
  try {
    fs.rmSync(path.join(SENDERS_AUTH_DIR, id), { recursive: true, force: true });
  } catch (err) {
    console.error(`[Rzone][Sender:${id}] Gagal hapus folder sesi:`, err?.message);
  }
  emitRemoved(id);
  return "ok";
}

/**
 * Sambungkan ulang SEMUA sender yang tercatat di database, dipanggil
 * sekali saat server baru nyala -- supaya sender yang sudah pernah
 * dipasang tidak perlu discan/pairing ulang tiap kali server restart.
 */
async function reconnectAllFromRegistry() {
  const records = db.listSenderRecords();
  for (const r of records) {
    startSenderSocket(r.id, { label: r.label, ownerId: r.ownerId }).catch((err) => {
      console.error(`[Rzone][Sender:${r.id}] Gagal menyambung ulang:`, err?.message);
    });
  }
  if (records.length > 0) {
    console.log(`[Rzone] Menyambungkan ulang ${records.length} sender dari sesi tersimpan...`);
  }
}

function pickRandomEmoji(emojis) {
  return emojis[Math.floor(Math.random() * emojis.length)];
}

/**
 * Ambil JID channel dari kode undangannya (di-cache per sender supaya
 * tidak berulang kali minta metadata ke server WhatsApp untuk link
 * channel yang sama).
 */
async function resolveChannelJid(record, inviteCode) {
  if (record.channelJidCache.has(inviteCode)) {
    return record.channelJidCache.get(inviteCode);
  }
  const meta = await record.sock.newsletterMetadata("invite", inviteCode);
  if (!meta?.id) {
    throw new Error("Channel tidak ditemukan (link salah atau channel sudah tidak ada).");
  }
  record.channelJidCache.set(inviteCode, meta.id);
  return meta.id;
}

/**
 * 1 sender mereaksi 1 POSTINGAN CHANNEL (bukan pesan grup). Tidak perlu
 * follow channel-nya -- cukup JID channel + ID postingan, dikirim langsung
 * lewat `newsletterReactMessage`. Memilih SATU emoji acak dari daftar.
 */
async function reactWithSender(record, link, emojis) {
  const parsed = parseChannelLink(link);
  if (!parsed) {
    return {
      id: record.id,
      ok: false,
      reason: "Link bukan link Channel/Saluran WhatsApp yang valid (format: whatsapp.com/channel/...).",
    };
  }
  if (!parsed.messageId) {
    return {
      id: record.id,
      ok: false,
      reason:
        "Link harus link POSTINGAN spesifik (ada ID angka di akhir URL, contoh: .../channel/xxxx/123), bukan cuma link channel-nya saja.",
    };
  }
  if (typeof record.sock.newsletterReactMessage !== "function") {
    return {
      id: record.id,
      ok: false,
      reason: "Versi Baileys sender ini tidak mendukung reaksi Channel. Update paket @whiskeysockets/baileys.",
    };
  }

  const emoji = pickRandomEmoji(emojis);
  try {
    const channelJid = await resolveChannelJid(record, parsed.inviteCode);
    await record.sock.newsletterReactMessage(channelJid, parsed.messageId, emoji);
    return { id: record.id, ok: true, emoji };
  } catch (err) {
    return { id: record.id, ok: false, reason: err?.message || "Gagal mereaksi." };
  }
}

module.exports = {
  setSocketIo,
  listSenders,
  getActiveCount,
  getActiveSenders,
  createSender,
  removeSender,
  reconnectAllFromRegistry,
  reactWithSender,
};
