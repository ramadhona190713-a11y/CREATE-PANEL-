/**
 * Antrian GLOBAL sederhana: memastikan setiap "pekerjaan" yang masuk
 * dieksekusi berurutan (satu per satu) dengan jarak minimal `spacingMs`
 * dari eksekusi sebelumnya — berlaku untuk SEMUA pemanggil, tidak peduli
 * dari mana asalnya (web gratis, API developer, dst).
 *
 * Kenapa ini perlu: nomor WhatsApp bot (satu-satunya "pengirim" untuk
 * semua orang) bisa kena limit anti-spam WhatsApp sendiri kalau mengirim
 * pesan/command terlalu rapat saat banyak orang memakainya bersamaan.
 * Contoh kasus dari kebutuhan proyek ini: kalau ada request masuk di
 * detik ke-1 dan request lain masuk di detik ke-6, request kedua tidak
 * langsung dieksekusi di detik ke-6 — dia baru dieksekusi di detik ke-11
 * (1 + 10), supaya jarak ANTAR EKSEKUSI tetap konsisten minimal
 * `spacingMs`, bukan cuma jarak antar kedatangan request.
 *
 * Cara kerja: begitu job masuk, waktu eksekusinya langsung "dipesan"
 * secara SYNCHRONOUS (`scheduledAt = max(now, lastScheduledAt + spacingMs)`)
 * sebelum job itu benar-benar menunggu (delay). Karena Node.js
 * single-threaded, langkah pemesanan slot waktu ini tidak mungkin
 * "ditabrak" oleh job lain yang masuk di waktu yang (hampir) bersamaan —
 * jadi urutan & jaraknya tetap konsisten walau banyak request datang
 * serentak.
 */

function createGlobalQueue(spacingMs) {
  let lastScheduledAt = 0;

  function enqueue(fn) {
    const now = Date.now();
    const scheduledAt = Math.max(now, lastScheduledAt + spacingMs);
    lastScheduledAt = scheduledAt;
    const delay = scheduledAt - now;

    return new Promise((resolve, reject) => {
      setTimeout(() => {
        Promise.resolve()
          .then(fn)
          .then(resolve, reject);
      }, delay);
    });
  }

  return { enqueue };
}

module.exports = { createGlobalQueue };
