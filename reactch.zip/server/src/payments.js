/**
 * Integrasi Payment Gateway FinCloud (Dynamic QRIS).
 * Base URL: https://api.fincloud.my.id/v1
 *
 * Endpoints:
 *   POST /create_invoice  — buat tagihan QRIS
 *   POST /cek_status      — cek status pembayaran
 *   POST /cancel_invoice  — batalkan invoice belum terbayar
 *
 * Signature wajib untuk create_invoice:
 *   HMAC-SHA256(reff_id + ":" + nominal, apikey)
 */

const crypto = require("crypto");
const QRCode = require("qrcode");
const config = require("../config.json");
const coins = require("./coins");
const db = require("./db");

const FINCLOUD_BASE = "https://api.fincloud.my.id/v1";
const REQUEST_TIMEOUT_MS = 15000;

function getApiKey() {
  return config.fincloud?.apiKey || "";
}

function makeSignature(reffId, nominal) {
  const apiKey = getApiKey();
  const payload = `${reffId}:${nominal}`;
  return crypto.createHmac("sha256", apiKey).update(payload).digest("hex");
}

/**
 * POST JSON ke FinCloud. Selalu mengembalikan object (tidak pernah melempar
 * karena body bukan JSON), supaya pemanggil bisa membaca `status`/`msg`.
 */
async function callFinCloud(endpoint, body) {
  const apiKey = getApiKey();
  const res = await fetch(`${FINCLOUD_BASE}/${endpoint}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ apikey: apiKey, ...body }),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
  });

  const raw = await res.text();
  try {
    return JSON.parse(raw);
  } catch {
    return { status: false, msg: `Respons payment gateway tidak valid (HTTP ${res.status}).` };
  }
}

/**
 * Ambil data QR dari respons FinCloud. Nama field bisa berbeda antar
 * endpoint/versi (qr_url, qris_url, qr_string, qris_string, ...), jadi
 * dicek semuanya -- ini penyebab QRIS tidak muncul sebelumnya: create_invoice
 * mengembalikan `qr_string`/`qr_url`, sementara kode lama hanya membaca
 * `qris_string`/`qris_url`.
 */
function pickFirst(obj, keys) {
  for (const k of keys) {
    const v = obj?.[k];
    if (typeof v === "string" && v.trim() !== "") return v.trim();
  }
  return null;
}

function extractQr(data) {
  const d = data && typeof data === "object" ? data : {};
  let qrString = pickFirst(d, ["qr_string", "qris_string", "qris", "qr_content", "qr_code", "qrcode", "emv"]);
  let qrUrl = pickFirst(d, ["qr_url", "qris_url", "qr_image", "qr_image_url", "qris_image", "image_url", "qr"]);

  // Beberapa gateway mengisi string EMV (000201...) ke field "url", atau
  // sebaliknya. Tukar kalau jelas salah tempat.
  if (qrUrl && /^0002\d{2}/.test(qrUrl) && !qrString) {
    qrString = qrUrl;
    qrUrl = null;
  }
  if (qrString && /^(https?:\/\/|data:image\/)/i.test(qrString) && !qrUrl) {
    qrUrl = qrString;
    qrString = null;
  }

  // URL relatif -> jadikan absolut ke domain FinCloud.
  if (qrUrl && qrUrl.startsWith("/")) {
    qrUrl = "https://api.fincloud.my.id" + qrUrl;
  }

  // Base64 mentah tanpa prefix data URL.
  if (qrUrl && /^[A-Za-z0-9+/=]{200,}$/.test(qrUrl)) {
    qrUrl = `data:image/png;base64,${qrUrl}`;
  }

  return {
    qrUrl,
    qrString,
    checkoutUrl: pickFirst(d, ["checkout_url", "payment_url", "pay_url", "url"]),
  };
}

/**
 * Ubah string QRIS (EMV) jadi gambar PNG (data URL) di server, jadi tidak
 * tergantung layanan pihak ketiga (api.qrserver.com) yang bisa diblokir
 * atau down.
 */
async function qrStringToDataUrl(qrString) {
  if (!qrString) return null;
  try {
    return await QRCode.toDataURL(qrString, { errorCorrectionLevel: "M", margin: 2, width: 420 });
  } catch (err) {
    console.error("[Payments] Gagal membuat gambar QR:", err.message);
    return null;
  }
}

/**
 * Bentuk objek QR siap-tampil untuk frontend: selalu usahakan ada `qrImage`
 * (gambar yang bisa langsung dipasang di <img src>).
 */
async function buildQrPayload(data) {
  const { qrUrl, qrString, checkoutUrl } = extractQr(data);
  let qrImage = qrUrl;
  if (!qrImage && qrString) qrImage = await qrStringToDataUrl(qrString);
  return { qrImage: qrImage || null, qrUrl, qrString, checkoutUrl };
}

/**
 * Buat invoice QRIS di FinCloud.
 */
function createInvoice(reffId, nominal) {
  return callFinCloud("create_invoice", {
    nominal,
    reff_id: reffId,
    signature: makeSignature(reffId, nominal),
  });
}

/**
 * Cek status pembayaran invoice.
 */
function checkStatus(reffId) {
  return callFinCloud("cek_status", { reff_id: reffId });
}

/**
 * Batalkan invoice yang belum dibayar.
 */
function cancelInvoice(reffId) {
  return callFinCloud("cancel_invoice", { reff_id: reffId });
}

/**
 * Buat order top up lokal + simpan ke DB untuk tracking.
 */
function createOrder(userId, coinType, coinAmount, totalPrice) {
  const reffId = `RZ-${Date.now()}-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;
  db.addOrder({
    reffId,
    userId,
    coinType,
    coinAmount,
    totalPrice,
    status: "pending",
    createdAt: new Date().toISOString(),
    paidAt: null,
  });
  return reffId;
}

function coinLabel(order) {
  return coins.COIN_TYPES[order.coinType]?.label || order.coinType;
}

function normalizeGatewayStatus(data) {
  return String(data?.status || "").toLowerCase();
}

const PAID_STATUSES = new Set(["paid", "success", "settled", "settlement", "completed", "berhasil", "lunas"]);
const FAILED_STATUSES = new Set(["failed", "expired", "cancelled", "canceled", "cancel", "gagal"]);

// Mencegah 2 pengecekan bersamaan (auto-check 4 detik + klik "Cek Status")
// sama-sama meng-credit koin untuk order yang sama.
const inFlight = new Map(); // reffId -> Promise

/**
 * Cek status pembayaran + credit koin kalau sudah paid.
 * Idempotent: kalau order sudah "paid" tidak akan credit ulang, termasuk
 * kalau dua request datang bersamaan.
 */
function processPaymentStatus(reffId) {
  if (inFlight.has(reffId)) return inFlight.get(reffId);
  const p = doProcessPaymentStatus(reffId).finally(() => inFlight.delete(reffId));
  inFlight.set(reffId, p);
  return p;
}

async function doProcessPaymentStatus(reffId) {
  const order = db.findOrder(reffId);
  if (!order) return { status: "not_found", message: "Order tidak ditemukan." };
  if (order.status === "paid") {
    return { status: "paid", message: `Pembayaran sudah selesai. +${order.coinAmount} koin ${coinLabel(order)}.` };
  }
  if (order.status === "cancelled") return { status: "cancelled", message: "Invoice sudah dibatalkan." };
  if (order.status === "expired") return { status: "expired", message: "Invoice sudah kedaluwarsa." };
  if (order.status === "failed") return { status: "expired", message: "Order gagal dibuat." };

  let result;
  try {
    result = await checkStatus(reffId);
  } catch (err) {
    return { status: "error", message: "Gagal menghubungi payment gateway. Coba lagi." };
  }

  // Bentuk respons FinCloud:
  // { status: true, msg, data: { reff_id, nominal, total_bayar,
  //   status: "pending"|"paid"|..., qr_string, qr_url } }
  const data = result?.data || {};
  const gwStatus = normalizeGatewayStatus(data);

  if (PAID_STATUSES.has(gwStatus)) {
    // Re-baca order setelah await, jaga-jaga status berubah selama menunggu.
    const fresh = db.findOrder(reffId);
    if (fresh && fresh.status !== "paid") {
      coins.addCoins(fresh.userId, fresh.coinType, fresh.coinAmount);
      db.updateOrderStatus(reffId, "paid");
    }
    return {
      status: "paid",
      message: `Pembayaran berhasil! +${order.coinAmount} koin ${coinLabel(order)} sudah masuk.`,
    };
  }

  if (FAILED_STATUSES.has(gwStatus)) {
    db.updateOrderStatus(reffId, "expired");
    return { status: "expired", message: "Pembayaran gagal atau kedaluwarsa." };
  }

  if (result?.status === false && !gwStatus) {
    // Gateway menjawab error (mis. invoice tidak ditemukan / sementara gangguan).
    return { status: "pending", message: result?.msg || "Menunggu pembayaran..." };
  }

  const qr = await buildQrPayload(data);
  return {
    status: "pending",
    message: "Menunggu pembayaran...",
    ...qr,
    totalBayar: data.total_bayar ?? order.totalPrice,
  };
}

module.exports = {
  createInvoice,
  checkStatus,
  cancelInvoice,
  createOrder,
  processPaymentStatus,
  makeSignature,
  extractQr,
  buildQrPayload,
};
