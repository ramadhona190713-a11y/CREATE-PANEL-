/**
 * Antrian GLOBAL untuk eksekusi `.reactch` (lihat globalQueue.js).
 * Jarak minimal 15 detik antar eksekusi, berlaku untuk SEMUA sumber
 * (web gratis /api/react MAUPUN API developer /api/dev/react) sekaligus
 * — supaya nomor bot tidak mengetik command terlalu rapat ke grup.
 *
 * Nilai 15000 ms ini sengaja ditulis di kode (bukan config.json), sesuai
 * permintaan: ini dianggap perilaku "normal"/tetap dari sistem, bukan
 * angka yang perlu diubah-ubah operator seperti limit harian.
 */
const { createGlobalQueue } = require("./globalQueue");

const REACT_SPACING_MS = 15000;

module.exports = createGlobalQueue(REACT_SPACING_MS);
