/**
 * Logika eksekusi "react" yang SAMA dipakai oleh /api/react (web) dan
 * /api/dev/react (API developer) -- supaya perilakunya konsisten.
 *
 * Model baru:
 *   - SETIAP sender publik yang sedang aktif memilih SATU emoji secara
 *     ACAK dari daftar emoji yang diminta, lalu mereaksi pesan targetnya
 *     masing-masing. Jumlah reaksi yang muncul di pesan target = jumlah
 *     sender aktif saat itu.
 *   - Kalau controller (botrc) menyala DAN sedang tersambung, controller
 *     ikut menambahkan reaksinya sendiri (mekanisme lama: command
 *     `.reactch`, reaksi berurutan untuk SEMUA emoji yang diminta) --
 *     ini di LUAR/tambahan dari reaksi para sender publik.
 *
 * Aturan wajib-tidaknya sender aktif TERGANTUNG `botrc`:
 *   - botrc = true  -> request TETAP BOLEH diproses walau sender aktif 0
 *     (controller bisa jalan sendirian tanpa bantuan sender publik).
 *   - botrc = false -> minimal HARUS ada 1 sender aktif, kalau tidak
 *     request DITOLAK (tidak diproses sama sekali).
 */

const senderPool = require("./senderPool");
const senderReactQueue = require("./senderReactQueue");
const reactQueue = require("./reactQueue");
const controllerBot = require("./controllerBot");
const systemStatus = require("./systemStatus");

class NoActiveSenderError extends Error {
  constructor() {
    super("Tidak ada sender WhatsApp yang aktif saat ini. Request tidak bisa diproses.");
    this.code = "NO_ACTIVE_SENDER";
  }
}

class SystemBlockedError extends Error {
  constructor() {
    super(systemStatus.blockedMessage() || "Sedang tidak bisa memproses react.");
    this.code = "SYSTEM_BLOCKED";
  }
}

async function executeReact({ link, emojis, targetGroupIds }) {
  // Jaring pengaman kedua (selain middleware di routes/react.js &
  // routes/dev.js) -- kalau web closed atau maintenance, TIDAK ADA reaksi
  // yang boleh terkirim lewat jalur mana pun.
  if (systemStatus.isBlocked()) {
    throw new SystemBlockedError();
  }

  const activeSenders = senderPool.getActiveSenders();
  const controllerEnabled = controllerBot.isEnabled();

  // Sender aktif WAJIB ada HANYA kalau controller (botrc) sedang mati.
  // Kalau botrc=true, controller dianggap sanggup jalan sendirian.
  if (activeSenders.length === 0 && !controllerEnabled) {
    throw new NoActiveSenderError();
  }

  // Semua sender "mendaftarkan" slot antriannya secara sinkron di sini
  // (lihat globalQueue.js) -- baru kemudian masing-masing menunggu
  // giliran & benar-benar mengirim reaksinya.
  const senderResults = await Promise.all(
    activeSenders.map((sender) =>
      senderReactQueue.enqueue(() => senderPool.reactWithSender(sender, link, emojis))
    )
  );

  let controllerResult = null;
  if (controllerEnabled && controllerBot.getStatus().connected) {
    try {
      const result = await reactQueue.enqueue(() =>
        controllerBot.sendReactchCommand({ link, emojis, targetGroupIds })
      );
      controllerResult = { ok: true, ...result };
    } catch (err) {
      controllerResult = { ok: false, error: err.message };
    }
  }

  const successCount = senderResults.filter((r) => r.ok).length;

  return {
    activeSenderCount: activeSenders.length,
    successCount,
    senderResults,
    controllerUsed: controllerResult !== null,
    controllerResult,
  };
}

/**
 * true kalau minimal 1 reaksi benar-benar terkirim (dari sender publik atau
 * controller). Dipakai untuk memutuskan apakah koin perlu dikembalikan.
 */
function didSucceed(result) {
  if (!result) return false;
  if (result.successCount > 0) return true;
  const cr = result.controllerResult;
  return Boolean(cr && cr.ok && Array.isArray(cr.results) && cr.results.some((r) => r.ok));
}

/**
 * Validasi input umum react (web & API). Return string error, atau null kalau valid.
 */
function validateReactInput(link, emojis) {
  if (!link || typeof link !== "string" || link.length > 500) {
    return "Field 'link' wajib diisi (maksimal 500 karakter).";
  }
  if (!Array.isArray(emojis) || emojis.length === 0) {
    return "Field 'emojis' wajib diisi berupa array, contoh: [\"emoji1\", \"emoji2\"].";
  }
  if (emojis.length > 20 || emojis.some((e) => typeof e !== "string" || !e.trim() || e.length > 16)) {
    return "Emoji tidak valid (maksimal 20 emoji, tiap emoji maksimal 16 karakter).";
  }
  return null;
}

module.exports = { executeReact, didSucceed, validateReactInput, NoActiveSenderError, SystemBlockedError };
