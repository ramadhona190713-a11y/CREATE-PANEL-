// account.js — Account page logic.
(function () {
  const loginGateCard = document.getElementById("loginGateCard");
  const accountCard = document.getElementById("accountCard");
  const emailHeading = document.getElementById("emailHeading");
  const accGreen = document.getElementById("accGreen");
  const accYellow = document.getElementById("accYellow");
  const accBlue = document.getElementById("accBlue");
  const greenRestock = document.getElementById("greenRestock");
  const blueRestock = document.getElementById("blueRestock");
  const logoutBtn = document.getElementById("logoutBtn");

  logoutBtn?.addEventListener("click", () => window.RzoneAuth.logout());

  (async function init() {
    const user = await window.RzoneAuth.fetchMe();
    if (!user || !user.ok) {
      loginGateCard.hidden = false;
      accountCard.hidden = true;
      return;
    }
    loginGateCard.hidden = true;
    accountCard.hidden = false;
    emailHeading.textContent = user.email;

    // Load coin info
    fetch("/api/topup/info")
      .then((r) => r.json())
      .then((d) => {
        if (!d.ok) return;
        accGreen.textContent = d.coins.green?.balance ?? 0;
        accYellow.textContent = d.coins.yellow?.balance ?? 0;
        accBlue.textContent = d.coins.blue?.balance ?? 0;
        greenRestock.textContent = d.coins.green?.dailyRestock ?? 2;
        blueRestock.textContent = d.coins.blue?.dailyRestock ?? 10;
      })
      .catch(() => {});
  })();
})();