// home.js — Auto React page logic with coin selection (green/yellow only).
(function () {
  const loginGateCard = document.getElementById("loginGateCard");
  const mainCard = document.getElementById("mainCard");
  const activeSenderText = document.getElementById("activeSenderText");
  const form = document.getElementById("reactForm");
  const linkInput = document.getElementById("link");
  const emojiInput = document.getElementById("emojis");
  const submitBtn = document.getElementById("submitBtn");
  const preview = document.getElementById("preview");
  const previewEmojis = document.getElementById("previewEmojis");
  const errorBox = document.getElementById("errorBox");
  const errorText = document.getElementById("errorText");
  const successBox = document.getElementById("successBox");
  const successText = document.getElementById("successText");

  const coinGreen = document.getElementById("coinGreen");
  const coinYellow = document.getElementById("coinYellow");
  const coinGreenBal = document.getElementById("coinGreenBal");
  const coinYellowBal = document.getElementById("coinYellowBal");
  const greenCount = document.getElementById("greenCount");
  const yellowCount = document.getElementById("yellowCount");

  let selectedCoin = "green";
  let coinBalances = { green: 0, yellow: 0 };
  let activeSenderCount = 0;
  let controllerEnabled = false;

  function senderRequirementMet() {
    return activeSenderCount > 0 || controllerEnabled;
  }

  function renderSenderInfo() {
    if (!activeSenderText) return;
    if (activeSenderCount > 0) {
      activeSenderText.textContent = `${activeSenderCount} sender aktif`;
    } else if (controllerEnabled) {
      activeSenderText.textContent = "bot controller aktif (tanpa sender)";
    } else {
      activeSenderText.textContent = "TIDAK ADA sender aktif";
    }
    updateSubmitState();
  }

  function refreshSenderCount() {
    fetch("/api/pairing/senders")
      .then((r) => r.json())
      .then((d) => { activeSenderCount = d.activeCount || 0; renderSenderInfo(); })
      .catch(() => {});
  }

  function refreshController() {
    fetch("/api/pairing/controller/status")
      .then((r) => r.json())
      .then((d) => { controllerEnabled = Boolean(d.enabled); renderSenderInfo(); })
      .catch(() => {});
  }

  function renderCoinBalances() {
    greenCount.textContent = coinBalances.green;
    yellowCount.textContent = coinBalances.yellow;
    coinGreenBal.textContent = `${coinBalances.green} koin`;
    coinYellowBal.textContent = `${coinBalances.yellow} koin`;
    updateSubmitState();
  }

  function selectCoin(type) {
    selectedCoin = type;
    coinGreen.className = "coin-option" + (type === "green" ? " selected-green" : "");
    coinYellow.className = "coin-option" + (type === "yellow" ? " selected-yellow" : "");
    updateSubmitState();
  }

  coinGreen?.addEventListener("click", () => selectCoin("green"));
  coinYellow?.addEventListener("click", () => selectCoin("yellow"));

  function parseEmojis() {
    return [...new Set(emojiInput.value.split(",").map((e) => e.trim()).filter(Boolean))];
  }

  function updatePreview() {
    const emojis = parseEmojis();
    if (emojis.length > 0) {
      preview.hidden = false;
      previewEmojis.textContent = emojis.join(" ");
    } else {
      preview.hidden = true;
    }
    updateSubmitState();
  }

  function coinExhausted() {
    return (coinBalances[selectedCoin] || 0) <= 0;
  }

  function updateSubmitState() {
    const canSubmit =
      !coinExhausted() &&
      senderRequirementMet() &&
      linkInput.value.trim() &&
      parseEmojis().length > 0;
    submitBtn.disabled = !canSubmit;
    if (coinExhausted()) {
      submitBtn.textContent = "Koin Habis — Top Up Dulu";
    } else if (!senderRequirementMet()) {
      submitBtn.textContent = "Tidak Ada Sender Aktif";
    } else {
      submitBtn.textContent = "Tambahkan React";
    }
  }

  function showError(msg) { errorText.textContent = msg; errorBox.hidden = false; }
  function hideMessages() { errorBox.hidden = true; successBox.hidden = true; }

  function setLoading(loading) {
    submitBtn.disabled = loading || coinExhausted() || !senderRequirementMet();
    if (loading) {
      submitBtn.innerHTML = '<span class="spinner"></span> Memproses...';
    } else {
      updateSubmitState();
    }
  }

  emojiInput.addEventListener("input", updatePreview);
  linkInput.addEventListener("input", updateSubmitState);

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    hideMessages();

    const link = linkInput.value.trim();
    const emojis = parseEmojis();

    if (!link) { showError("Isi link saluran terlebih dahulu."); return; }
    if (emojis.length === 0) { showError("Isi minimal 1 emoji."); return; }
    if (coinExhausted()) { showError("Koin habis. Top up dulu di halaman Top Up."); return; }
    if (!senderRequirementMet()) { showError("Tidak ada sender aktif. Coba lagi nanti."); return; }

    setLoading(true);
    try {
      const res = await fetch("/api/react", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ link, emojis, coinType: selectedCoin }),
      });
      let data = {};
      try { data = await res.json(); } catch { /* respons bukan JSON */ }
      if (data.coins) {
        coinBalances.green = data.coins.green?.balance ?? coinBalances.green;
        coinBalances.yellow = data.coins.yellow?.balance ?? coinBalances.yellow;
        renderCoinBalances();
      }
      if (!res.ok) throw new Error(data.error || "Gagal memproses.");

      const successCount = data.result?.successCount ?? 0;
      const activeCount = data.result?.activeSenderCount ?? 0;

      if (data.success === false) {
        // Tidak ada reaksi yang terkirim -> koin sudah dikembalikan server.
        const reasons = (data.result?.senderResults || [])
          .map((r) => r.reason)
          .filter(Boolean);
        const detail = reasons.length ? ` Penyebab: ${[...new Set(reasons)][0]}` : "";
        showError(`React gagal, koin kamu dikembalikan.${detail}`);
      } else {
        successText.textContent = `Berhasil! ${successCount}/${activeCount} sender mereaksi.`;
        successBox.hidden = false;
        linkInput.value = "";
        emojiInput.value = "";
        updatePreview();
      }

      // Update coin balances from response
      if (data.coins) {
        coinBalances.green = data.coins.green?.balance ?? 0;
        coinBalances.yellow = data.coins.yellow?.balance ?? 0;
        renderCoinBalances();
      }
    } catch (err) {
      showError(err.message);
      // Koin bisa sudah dikembalikan server -- segarkan saldo supaya akurat.
      refreshCoins();
    } finally {
      setLoading(false);
    }
  });

  // Init
  (async function init() {
    const user = await window.RzoneAuth.fetchMe();
    if (!user || !user.ok) {
      loginGateCard.hidden = false;
      mainCard.hidden = true;
      return;
    }
    loginGateCard.hidden = true;
    mainCard.hidden = false;

    refreshSenderCount();
    refreshController();

    if (window.__rzoneSocket) {
      window.__rzoneSocket.on("sender:update", refreshSenderCount);
      window.__rzoneSocket.on("sender:removed", refreshSenderCount);
    }

    refreshCoins();
  })();

  function refreshCoins() {
    fetch("/api/react/status")
      .then((r) => r.json())
      .then((d) => {
        if (d.coins) {
          coinBalances.green = d.coins.green?.balance ?? 0;
          coinBalances.yellow = d.coins.yellow?.balance ?? 0;
          renderCoinBalances();
        }
        if (d.activeSenderCount !== undefined) {
          activeSenderCount = d.activeSenderCount;
          renderSenderInfo();
        }
      })
      .catch(() => {});
  }
})();