// developer.js — Developer page logic (API key + blue coins).
(function () {
  const loginGateCard = document.getElementById("loginGateCard");
  const apiKeyCard = document.getElementById("apiKeyCard");
  const dashboardCard = document.getElementById("dashboardCard");
  const emailText = document.getElementById("emailText");
  const blueBalance = document.getElementById("blueBalance");
  const apiKeyText = document.getElementById("apiKeyText");
  const copyKeyBtn = document.getElementById("copyKeyBtn");
  const regenBtn = document.getElementById("regenBtn");
  const logoutBtn = document.getElementById("logoutBtn");
  const blueStat = document.getElementById("blueStat");
  const totalStat = document.getElementById("totalStat");
  const historyTable = document.getElementById("historyTable");
  const historyEmpty = document.getElementById("historyEmpty");

  let apiKey = null;
  let regenConfirm = false;

  function formatTime(iso) {
    try {
      return new Date(iso).toLocaleString("id-ID", { timeZone: "Asia/Jakarta", dateStyle: "medium", timeStyle: "short" });
    } catch { return iso; }
  }

  function renderHistory(history) {
    historyTable.innerHTML = "";
    if (!history || history.length === 0) { historyEmpty.hidden = false; return; }
    historyEmpty.hidden = true;
    history.forEach((item) => {
      const row = document.createElement("div");
      row.className = "history-item";
      const linkEl = document.createElement("span");
      linkEl.className = "hi-link";
      linkEl.textContent = item.link; // textContent: cegah XSS dari link buatan user
      const timeEl = document.createElement("span");
      timeEl.className = "hi-time";
      timeEl.textContent = formatTime(item.at);
      row.append(linkEl, timeEl);
      historyTable.appendChild(row);
    });
  }

  function loadStats() {
    fetch("/api/dev/stats")
      .then((r) => r.json())
      .then((d) => {
        if (!d.ok) return;
        blueStat.textContent = d.coins?.blue?.balance ?? 0;
        blueBalance.textContent = d.coins?.blue?.balance ?? 0;
        totalStat.textContent = d.stats?.totalRequests ?? 0;
        renderHistory(d.history);
      })
      .catch(() => {});
  }

  copyKeyBtn?.addEventListener("click", () => {
    if (!apiKey) return;
    const label = copyKeyBtn.querySelector(".btn-label");
    const done = () => {
      if (label) label.textContent = "Tersalin";
      setTimeout(() => { if (label) label.textContent = "Salin Key"; }, 1500);
    };
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(apiKey).then(done).catch(() => alert("Gagal menyalin. Salin manual dari kotak di atas."));
    } else {
      alert("Browser tidak mendukung salin otomatis. Salin manual dari kotak di atas.");
    }
  });

  regenBtn?.addEventListener("click", async () => {
    const regenLabel = regenBtn.querySelector(".btn-label");
    if (!regenConfirm) {
      regenConfirm = true;
      if (regenLabel) regenLabel.textContent = "Yakin? Klik lagi";
      setTimeout(() => {
        if (regenConfirm) { regenConfirm = false; if (regenLabel) regenLabel.textContent = "Buat Ulang"; }
      }, 4000);
      return;
    }
    try {
      const res = await fetch("/api/dev/regenerate", { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Gagal.");
      apiKey = data.apiKey;
      apiKeyText.textContent = apiKey;
      loadStats();
    } catch (err) { alert(err.message); }
    finally {
      const l = regenBtn.querySelector(".btn-label");
      if (l) l.textContent = "Buat Ulang";
      regenConfirm = false;
    }
  });

  logoutBtn?.addEventListener("click", () => window.RzoneAuth.logout());

  (async function init() {
    const user = await window.RzoneAuth.fetchMe();
    if (!user || !user.ok) {
      loginGateCard.hidden = false;
      apiKeyCard.hidden = true;
      dashboardCard.hidden = true;
      return;
    }
    loginGateCard.hidden = true;
    apiKeyCard.hidden = false;
    dashboardCard.hidden = false;
    emailText.textContent = user.email;
    apiKey = user.apiKey;
    apiKeyText.textContent = apiKey;
    loadStats();
  })();
})();