// topup.js — Top Up page: coin purchase with QRIS payment (FinCloud).
// Auto-check payment status every 4 seconds + manual check & cancel buttons.
(function () {
  const loginGateCard = document.getElementById("loginGateCard");
  const topupContent = document.getElementById("topupContent");
  const balGreen = document.getElementById("balGreen");
  const balYellow = document.getElementById("balYellow");
  const balBlue = document.getElementById("balBlue");

  const orderFormCard = document.getElementById("orderFormCard");
  const orderCoinTitle = document.getElementById("orderCoinTitle");
  const coinAmount = document.getElementById("coinAmount");
  const minBuyHint = document.getElementById("minBuyHint");
  const totalPrice = document.getElementById("totalPrice");
  const createOrderBtn = document.getElementById("createOrderBtn");
  const orderError = document.getElementById("orderError");
  const orderErrorText = document.getElementById("orderErrorText");

  const paymentCard = document.getElementById("paymentCard");
  const paymentStatus = document.getElementById("paymentStatus");
  const paymentAmount = document.getElementById("paymentAmount");
  const totalBayarNote = document.getElementById("totalBayarNote");
  const paymentReff = document.getElementById("paymentReff");
  const qrContainer = document.getElementById("qrContainer");
  const checkStatusBtn = document.getElementById("checkStatusBtn");
  const cancelBtn = document.getElementById("cancelBtn");
  const autoCheckHint = document.getElementById("autoCheckHint");
  const paidAlert = document.getElementById("paidAlert");
  const paidText = document.getElementById("paidText");
  const orderHistory = document.getElementById("orderHistory");

  const COIN_PRICES = { green: 500, yellow: 150, blue: 700 };
  const COIN_MIN = { green: 4, yellow: 10, blue: 5 };
  const COIN_NAMES = { green: "Hijau", yellow: "Kuning", blue: "Biru" };
  const icon = (name) => (window.RzoneIcons ? window.RzoneIcons.svg(name) : "");

  let selectedCoin = null;
  let currentReffId = null;
  let autoCheckInterval = null;
  let checking = false;
  let creating = false;

  function formatRp(n) {
    return "Rp" + Number(n || 0).toLocaleString("id-ID");
  }

  function escapeHtml(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  // fetch JSON yang tahan terhadap respons non-JSON (mis. halaman error proxy)
  async function api(url, options) {
    const res = await fetch(url, options);
    let data = {};
    try { data = await res.json(); } catch { /* biarkan kosong */ }
    return { res, data };
  }

  function setStatus(kind, text, iconName) {
    paymentStatus.className = "payment-status " + kind;
    paymentStatus.innerHTML = (iconName ? icon(iconName) + " " : "") + escapeHtml(text);
  }

  function loadBalances() {
    api("/api/topup/info")
      .then(({ data: d }) => {
        if (!d.ok) return;
        balGreen.textContent = d.coins.green?.balance ?? 0;
        balYellow.textContent = d.coins.yellow?.balance ?? 0;
        balBlue.textContent = d.coins.blue?.balance ?? 0;
      })
      .catch(() => {});
  }

  const STATUS_LABEL = {
    paid: "LUNAS",
    pending: "MENUNGGU",
    cancelled: "DIBATALKAN",
    expired: "KEDALUWARSA",
    failed: "GAGAL",
  };

  function loadHistory() {
    api("/api/topup/history")
      .then(({ data: d }) => {
        if (!d.ok || !d.orders || d.orders.length === 0) {
          orderHistory.innerHTML = '<p class="desc">Belum ada order.</p>';
          return;
        }
        orderHistory.innerHTML = d.orders.slice(0, 10).map((o) => {
          const statusLabel = STATUS_LABEL[o.status] || String(o.status || "").toUpperCase();
          const coinLabel = COIN_NAMES[o.coinType] || o.coinType;
          const resume = o.status === "pending"
            ? `<button class="btn btn-outline btn-sm hi-action" data-resume="${escapeHtml(o.reffId)}">Lanjutkan</button>`
            : "";
          return `<div class="history-item">
            <span class="hi-link"><b>${escapeHtml(statusLabel)}</b> — ${Number(o.coinAmount)} koin ${escapeHtml(coinLabel)} — ${formatRp(o.totalPrice)}</span>
            <span class="hi-time">${new Date(o.createdAt).toLocaleDateString("id-ID")}${resume}</span>
          </div>`;
        }).join("");
      })
      .catch(() => {});
  }

  // Lanjutkan pembayaran order yang masih menunggu (QR ditampilkan lagi)
  orderHistory?.addEventListener("click", async (e) => {
    const btn = e.target.closest("[data-resume]");
    if (!btn) return;
    btn.disabled = true;
    try {
      const { res, data } = await api("/api/topup/order/" + encodeURIComponent(btn.dataset.resume));
      if (!res.ok) throw new Error(data.error || "Gagal memuat order.");
      if (data.status !== "pending") { loadHistory(); return; }
      currentReffId = data.reffId;
      showPaymentCard(data);
      checkPaymentStatus();
    } catch (err) {
      alert(err.message);
    } finally {
      btn.disabled = false;
    }
  });

  // Coin selection
  document.querySelectorAll(".topup-card").forEach((card) => {
    card.addEventListener("click", () => {
      selectedCoin = card.dataset.coin;
      orderFormCard.hidden = false;
      orderCoinTitle.textContent = `Top Up Koin ${COIN_NAMES[selectedCoin]}`;
      minBuyHint.textContent = `Minimal ${COIN_MIN[selectedCoin]} koin · ${formatRp(COIN_PRICES[selectedCoin])}/koin`;
      coinAmount.value = COIN_MIN[selectedCoin];
      updateTotal();
      orderFormCard.scrollIntoView({ behavior: "smooth", block: "center" });
    });
  });

  function updateTotal() {
    if (!selectedCoin) return;
    const qty = parseInt(coinAmount.value, 10) || 0;
    totalPrice.textContent = formatRp(qty * COIN_PRICES[selectedCoin]);
  }
  coinAmount?.addEventListener("input", updateTotal);

  function setCreateBtnBusy(busy) {
    createOrderBtn.disabled = busy;
    createOrderBtn.innerHTML = busy
      ? '<span class="spinner"></span> Membuat order...'
      : icon("qr") + "<span>Buat Order &amp; Bayar QRIS</span>";
  }

  // Create order
  createOrderBtn?.addEventListener("click", async () => {
    if (creating || !selectedCoin) return;
    orderError.hidden = true;
    const qty = parseInt(coinAmount.value, 10);
    if (!qty || qty < COIN_MIN[selectedCoin]) {
      orderErrorText.textContent = `Minimal ${COIN_MIN[selectedCoin]} koin.`;
      orderError.hidden = false;
      return;
    }

    creating = true;
    setCreateBtnBusy(true);

    try {
      const { res, data } = await api("/api/topup/order", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ coinType: selectedCoin, amount: qty }),
      });
      if (!res.ok || !data.ok) throw new Error(data.error || "Gagal membuat order.");

      currentReffId = data.reffId;
      showPaymentCard(data);
      loadHistory();
    } catch (err) {
      orderErrorText.textContent = err.message;
      orderError.hidden = false;
    } finally {
      creating = false;
      setCreateBtnBusy(false);
    }
  });

  // Tampilkan QR: prioritas gambar siap-pakai dari server (qrImage), lalu qrUrl.
  function renderQr(data) {
    const src = data.qrImage || data.qrUrl;
    if (src) {
      qrContainer.innerHTML = `<div class="qr-box qr-large"><img class="qr-img" id="qrImgEl" alt="QRIS" /><p>Scan QRIS untuk membayar</p></div>`;
      const img = document.getElementById("qrImgEl");
      img.addEventListener("error", () => renderQrFallback(data));
      img.src = src; // diset lewat properti (bukan innerHTML) agar aman
      return true;
    }
    renderQrFallback(data);
    return false;
  }

  function renderQrFallback(data) {
    if (data.checkoutUrl) {
      qrContainer.innerHTML = `<p class="desc">QR belum bisa ditampilkan. <a href="${escapeHtml(data.checkoutUrl)}" target="_blank" rel="noopener">Buka halaman pembayaran</a>.</p>`;
    } else {
      qrContainer.innerHTML = `<p class="hint"><span class="spinner dark"></span> Menyiapkan QRIS... klik "Cek Status" kalau tidak muncul.</p>`;
    }
  }

  function showPaymentCard(data) {
    paymentCard.hidden = false;
    paidAlert.hidden = true;
    paymentAmount.textContent = formatRp(data.totalBayar || data.totalPrice);
    paymentReff.textContent = `Ref: ${data.reffId}`;
    setStatus("pending", "Menunggu pembayaran", "clock");
    autoCheckHint.hidden = false;
    checkStatusBtn.disabled = false;
    cancelBtn.disabled = false;

    // FinCloud menambah kode unik ke nominal -> total_bayar bisa beda dari totalPrice
    if (data.totalBayar && data.totalBayar !== data.totalPrice) {
      totalBayarNote.hidden = false;
      totalBayarNote.textContent = `Bayar PERSIS ${formatRp(data.totalBayar)} (termasuk kode unik ${data.kodeUnik || 0}) supaya otomatis terdeteksi.`;
    } else {
      totalBayarNote.hidden = true;
    }

    renderQr(data);

    startAutoCheck();
    paymentCard.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  function startAutoCheck() {
    stopAutoCheck();
    autoCheckInterval = setInterval(checkPaymentStatus, 4000);
  }

  function stopAutoCheck() {
    if (autoCheckInterval) {
      clearInterval(autoCheckInterval);
      autoCheckInterval = null;
    }
  }

  async function checkPaymentStatus() {
    if (!currentReffId || checking) return;
    checking = true;
    const reffId = currentReffId;
    try {
      const { res, data } = await api("/api/topup/check", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reffId }),
      });
      if (reffId !== currentReffId) return; // user sudah pindah ke order lain
      if (!res.ok) return;

      // Pasang QR kalau belum tampil tapi server sudah punya
      if (data.status === "pending" && (data.qrImage || data.qrUrl) && !qrContainer.querySelector("img")) {
        renderQr(data);
      }

      if (data.status === "paid") {
        stopAutoCheck();
        setStatus("paid", "Pembayaran Berhasil", "check-circle");
        autoCheckHint.hidden = true;
        qrContainer.innerHTML = "";
        checkStatusBtn.disabled = true;
        cancelBtn.disabled = true;
        paidAlert.hidden = false;
        paidText.textContent = data.message || "Pembayaran berhasil! Koin sudah masuk.";
        loadBalances();
        loadHistory();
      } else if (data.status === "expired" || data.status === "cancelled") {
        stopAutoCheck();
        setStatus("expired", data.status === "cancelled" ? "Dibatalkan" : "Kedaluwarsa", "x");
        autoCheckHint.hidden = true;
        qrContainer.innerHTML = "";
        checkStatusBtn.disabled = true;
        cancelBtn.disabled = true;
        loadHistory();
      }
    } catch { /* jaringan putus sementara, coba lagi di siklus berikutnya */ }
    finally { checking = false; }
  }

  checkStatusBtn?.addEventListener("click", checkPaymentStatus);

  cancelBtn?.addEventListener("click", async () => {
    if (!currentReffId) return;
    cancelBtn.disabled = true;
    try {
      const { res, data } = await api("/api/topup/cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reffId: currentReffId }),
      });
      if (!res.ok) throw new Error(data.error || "Gagal membatalkan.");
      stopAutoCheck();
      setStatus("expired", "Dibatalkan", "x");
      autoCheckHint.hidden = true;
      qrContainer.innerHTML = "";
      checkStatusBtn.disabled = true;
      loadHistory();
      loadBalances();
    } catch (err) {
      alert(err.message);
      cancelBtn.disabled = false;
      checkPaymentStatus();
    }
  });

  // Init
  (async function init() {
    const user = await window.RzoneAuth.fetchMe();
    if (!user || !user.ok) {
      loginGateCard.hidden = false;
      topupContent.hidden = true;
      return;
    }
    loginGateCard.hidden = true;
    topupContent.hidden = false;
    loadBalances();
    loadHistory();
  })();
})();
